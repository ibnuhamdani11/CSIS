@extends ('layouts/tema')

@section('title','Amount Of Paid Visit Report')

@section('card_title','Amount Of Paid Visit Report')

@section('isi')


@endsection
