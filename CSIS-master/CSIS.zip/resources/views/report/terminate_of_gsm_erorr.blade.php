@extends ('layouts/tema')

@section('title','Terminate Of GSM Error Report')

@section('card_title','Terminate Of GSM Error Report')

@section('isi')


@endsection
