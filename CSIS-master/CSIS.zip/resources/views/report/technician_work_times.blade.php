@extends ('layouts/tema')

@section('title','Technician Work Times Report')

@section('card_title','Technician Work Times Report')

@section('isi')


@endsection
