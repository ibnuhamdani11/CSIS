@extends ('layouts/tema')

@section('title','Equipment Used Report')

@section('card_title','Equipment Used Report')

@section('isi')


@endsection
