@extends ('layouts/tema')

@section('title','Terminate And Activation Of Gsm Report')

@section('card_title','Terminate And Activation Of Gsm Report')

@section('isi')


@endsection
