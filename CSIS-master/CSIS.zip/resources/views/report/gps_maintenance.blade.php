@extends ('layouts/tema')

@section('title','GPS Maintenance Report')

@section('card_title','GPS Maintenance Report')

@section('isi')


@endsection
