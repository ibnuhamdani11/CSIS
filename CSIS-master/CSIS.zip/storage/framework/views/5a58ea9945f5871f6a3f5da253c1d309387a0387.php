

<?php $__env->startSection('title','add customer'); ?>

<?php $__env->startSection('card_title','Add Customer'); ?>

<?php $__env->startSection('isi'); ?>



<div class="col-md-10 "><div class="x_panel">
								<div class="x_title">

                <div class="clearfix"></div>
								</div>
								<div class="x_content">
									<br />
                  <form method="post" action="/store_customer" autocomplete="off">
                  <?php echo csrf_field(); ?>
										<div class="form-group row ">
											<label class="control-label col-md-3 col-sm-3 label-align">Name</label>
											<div class="col-md-9 col-sm-9 ">
                      <input type="text" class="form-control" id="name" placeholder="input name" name="name" required>
                              <?php if($errors->has('name')): ?>
            
                                <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
            
                            <?php endif; ?>											
                          </div>
										</div>
										
										<div class="form-group row">
											<label class="control-label col-md-3 col-sm-3 label-align">Short Name</label>
											<div class="col-md-9 col-sm-9 ">
                      <input type="text" class="form-control" id="sn" placeholder="input short name" name="sn" >

											</div>
										</div>

                    <div class="form-group row">
											<label class="control-label col-md-3 col-sm-3 label-align">Bussiness Type <a data-toggle="modal" data-target="#Modalbt" class="btn btn-warning btn-sm">+</a></label>
											<div class="col-md-9 col-sm-9 ">
                      <select name="bt" id="bt" class="form-control">
                              <option value="" >Choose business type</option>
                            <?php $__currentLoopData = $bt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($bt->business_type); ?>"><?php echo e($bt->business_type); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
											</div>
										</div>

                    <div class="form-group row">
											<label class="control-label col-md-3 col-sm-3 label-align">Bussiness Conduct <a data-toggle="modal" data-target="#Modalbc" class="btn btn-warning btn-sm">+</a></label>
											<div class="col-md-9 col-sm-9 ">
                      <select name="bc" id="bc" class="form-control">
                              <option value="" >Choose business conduct</option>
                            <?php $__currentLoopData = $bc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($bc->business_conduct); ?>"><?php echo e($bc->business_conduct); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
											</div>
                    </div>
                    
                    <div class="form-group row">
											<label class="control-label col-md-3 col-sm-3 label-align">NPWP</label>
											<div class="col-md-9 col-sm-9 ">
                      <input type="number" class="form-control" id="npwp" placeholder="input npwp" name="npwp" >
                  <?php if($errors->has('npwp')): ?>
 
                  <span class="text-danger"><?php echo e($errors->first('npwp')); ?></span>

                  <?php endif; ?>
											</div>
										</div>

                    <div class="form-group row ">
											<label class="control-label col-md-3 col-sm-3 label-align">Remarks</label>
											<div class="col-md-9 col-sm-9 ">
                      <input type="text" class="form-control" id="remarks" placeholder="input remarks" name="remarks" >
											</div>
										</div>

                    <div class="form-group row">
											<label class="control-label col-md-3 col-sm-3 label-align">Code Name</label>
											<div class="col-md-9 col-sm-9 ">
                      <input type="text" class="form-control" id="code_name" placeholder="input code name" name="code_name" >

											</div>
										</div>
									


										<div class="ln_solid"></div>
										<div class="form-group">
											<div class="col-md-9 col-sm-9  offset-md-3">
												<button type="submit" class="btn btn-success">Save</button>
											</div>
										</div>

									</form>
								</div>
							</div>
						</div>


      

 <!-- Modal -->
 <div class="modal fade" id="Modalbt" >
    <div class="modal-dialog" >
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" >Add Business Type</h5>
              <button type="button" class="close" data-dismiss="modal" >
                &times;
              </button>
              </div>
              <div class="modal-body">
              <form action="/store_bt" method="POST">
              <?php echo csrf_field(); ?>
                <div class="form-group">
                  <input name="bt" type="text" class="form-control" id="exampleInputEmail1">
                </div>
            </div>
            <div class="modal-footer">
              <button type="submit" class="btn btn-info">Save</button>
              </form>
          </div>
        </div>
      </div>
      </div>
      </div>


      <!-- Modal BRAND -->
 <div class="modal fade" id="Modalbc" >
    <div class="modal-dialog" >
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" >Add Business Conduct</h5>
              <button type="button" class="close" data-dismiss="modal" >&times;</button>
              </div>
              <div class="modal-body">
              <form action="/store_bc" method="POST">
              <?php echo csrf_field(); ?>
                <div class="form-group">
                  <input name="bc" type="text" class="form-control" id="exampleInputEmail1">
                </div>
            </div>
            <div class="modal-footer">
              <button type="submit" class="btn btn-info">Save</button>
              </form>
          </div>
        </div>
      </div>
      </div>
      </div>


        <!-- Modal SERIES -->
 <div class="modal fade" id="Modalseries" >
    <div class="modal-dialog" >
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" >Add Series</h5>
              <button type="button" class="close" data-dismiss="modal" >&times;</button>
              </div>
              <div class="modal-body">
              <form action="/store_series" method="POST">
              <?php echo csrf_field(); ?>
                <div class="form-group">
                  <input name="series" type="text" class="form-control" id="exampleInputEmail1">
                </div>
            </div>
            <div class="modal-footer">
              <button type="submit" class="btn btn-info">Save</button>
              </form>
          </div>
        </div>
      </div>
      </div>
      </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/tema', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\CSIS\resources\views/customer/create_customer.blade.php ENDPATH**/ ?>