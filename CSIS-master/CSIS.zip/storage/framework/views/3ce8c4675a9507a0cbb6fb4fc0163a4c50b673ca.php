

<?php $__env->startSection('title','part'); ?>

<?php $__env->startSection('card_title','Add Part'); ?>

<?php $__env->startSection('isi'); ?>


        <div class="card-body">
        <form method="post" action="/store_mp" autocomplete="off">
	          <?php echo csrf_field(); ?>
                <div class="form-group">
                  <label for="part">Part</label>
                  <input type="text" class="form-control" id="part" placeholder="input part name" name="part" required>
                 <?php if($errors->has('part')): ?>
 
                    <span class="text-danger"><?php echo e($errors->first('part')); ?></span>
 
                <?php endif; ?>
                </div>
                <div>
                  <label for="series">Series</label>  
                  <!-- Button to Open the Modal -->
                  <a data-toggle="modal" data-target="#Modalseries"><img src="<?php echo e(asset('admin/assets/img/add.png')); ?>" width="10" height="10" ></i></a>
                 <select name="series" class="form-control">
                              <option value="" >Choose Series</option>
                            <?php $__currentLoopData = $series; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $series): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($series->id); ?>"><?php echo e($series->series); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div> <br>
                <div>
                  <label for="type">Type</label> 
                  <!-- Button to Open the Modal -->
                <a data-toggle="modal" data-target="#Modaltype"><img src="<?php echo e(asset('admin/assets/img/add.png')); ?>" width="10" height="10" ></i></a>

                    <select name="type" class="form-control">
                          <option value="">Choose Type</option>
                            <?php $__currentLoopData = $type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($type->id); ?>"><?php echo e($type->type); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div> <br>
                <div>
                <label for="merk">Brand</label> 
  <!-- Button to Open the Modal -->
  <a data-toggle="modal" data-target="#Modalbrand"><img src="<?php echo e(asset('admin/assets/img/add.png')); ?>" width="10" height="10" ></i></a>
                  <select name="merk" class="form-control">
                  <option value="">Choose Brand</option>
                            <?php $__currentLoopData = $merk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $merk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($merk->id); ?>"><?php echo e($merk->merk); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div> <br>
                     
                <button type="submit" class="btn btn-info btn-xs "> Save</button>
              </form>
                  </div>
                </div>
              </div>
            </div>
            </div>
          </div>
        </div>
      </div>
      
    
  </div>
 






 


 <!-- Modal -->
 <div class="modal fade" id="Modaltype" >
    <div class="modal-dialog" >
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" >Add Type</h5>
              <button type="button" class="close" data-dismiss="modal" >
                &times;
              </button>
              </div>
              <div class="modal-body">
              <form action="/store_type" method="POST" autocomplete="off">
              <?php echo csrf_field(); ?>
                <div class="form-group">
                  <input name="type" type="text" class="form-control" id="exampleInputEmail1">
                </div>
            </div>
            <div class="modal-footer">
              <button type="submit" class="btn btn-info">Save</button>
              </form>
          </div>
        </div>
      </div>
      </div>
      </div>


      <!-- Modal BRAND -->
 <div class="modal fade" id="Modalbrand" >
    <div class="modal-dialog" >
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" >Add Brand</h5>
              <button type="button" class="close" data-dismiss="modal" >&times;</button>
              </div>
              <div class="modal-body">
              <form action="/store_brand" method="POST" autocomplete="off">
              <?php echo csrf_field(); ?>
                <div class="form-group">
                  <input name="merk" type="text" class="form-control" id="exampleInputEmail1">
                </div>
            </div>
            <div class="modal-footer">
              <button type="submit" class="btn btn-info">Save</button>
              </form>
          </div>
        </div>
      </div>
      </div>
      </div>


        <!-- Modal SERIES -->
 <div class="modal fade" id="Modalseries" >
    <div class="modal-dialog" >
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" >Add Series</h5>
              <button type="button" class="close" data-dismiss="modal" >&times;</button>
              </div>
              <div class="modal-body">
              <form action="/store_series" method="POST" autocomplete="off">
              <?php echo csrf_field(); ?>
                <div class="form-group">
                  <input name="series" type="text" class="form-control" id="exampleInputEmail1">
                </div>
            </div>
            <div class="modal-footer">
              <button type="submit" class="btn btn-info">Save</button>
              </form>
          </div>
        </div>
      </div>
      </div>
      </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\CSIS\resources\views/create_mp.blade.php ENDPATH**/ ?>