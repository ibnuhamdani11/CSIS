

<?php $__env->startSection('title','part'); ?>

<?php $__env->startSection('card_title','Add Part'); ?>

<?php $__env->startSection('isi'); ?>

    <form method="POST" action="/update/part/<?php echo e($part->id); ?>">
    <?php echo method_field('patch'); ?>
    <?php echo csrf_field(); ?>

        <div class="form-group">
            <label for="part">Part</label>
        <input type="text" class="form-control" id="part" name="part" required value="<?php echo e($part['part']); ?>">
        <?php if($errors->has('part')): ?>
 
                    <span class="text-danger"><?php echo e($errors->first('part')); ?></span>
 
                <?php endif; ?>
        </div>
        <div class="form-group">
      <label for="series">series</label>
    <select name="series" class="form-control" >
    <option value="">Choose Series</option>
              <?php $__currentLoopData = $series; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $series): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($series->id==$part->id_series): ?>
                <option value="<?php echo e($series->id); ?>" selected='selected'><?php echo e($series->series); ?></option>
                <?php else: ?>
                <option value="<?php echo e($series->id); ?>"><?php echo e($series->series); ?></option>
                <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
  </div>
  <div class="form-group">
      <label for="type">type</label>
    <select name="type" class="form-control" >
    <option value="">Choose Type</option>
              <?php $__currentLoopData = $type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($type->id==$part->id_type): ?>
                <option value="<?php echo e($type->id); ?>" selected='selected'><?php echo e($type->type); ?></option>
                <?php else: ?>
                <option value="<?php echo e($type->id); ?>"><?php echo e($type->type); ?></option>
                <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
  </div>
  <div class="form-group">
      <label for="merk">Brand</label>
    <select name="merk" class="form-control" >
    <option value="">Choose Brand</option>
              <?php $__currentLoopData = $merk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $merk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($merk->id==$part->id_merk): ?>
                <option value="<?php echo e($merk->id); ?>" selected='selected'><?php echo e($merk->merk); ?></option>
                <?php else: ?>
                <option value="<?php echo e($merk->id); ?>"><?php echo e($merk->merk); ?></option>
                <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
  </div>
  <div class="form-group">
            <label for="sc">Serialized Code</label><br>
            <input type="radio" name="sc" value="Y"  <?php echo e($part->serialized_code == 'Y'? 'checked' : ''); ?>> Yes<br>
            <input type="radio" name="sc" value="N"  <?php echo e($part->serialized_code == 'N'? 'checked' : ''); ?>> No<br>
        
        </div>
  <button type="submit" class="btn btn-warning btn-xs "> Edit</button>
</form>


			
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\CSIS\resources\views/edit_part.blade.php ENDPATH**/ ?>