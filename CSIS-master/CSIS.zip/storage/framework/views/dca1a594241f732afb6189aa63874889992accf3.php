

<?php $__env->startSection('title','Technician Work Times Report'); ?>

<?php $__env->startSection('card_title','Technician Work Times Report'); ?>

<?php $__env->startSection('isi'); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/tema', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\CSIS\resources\views/report/technician_work_times.blade.php ENDPATH**/ ?>