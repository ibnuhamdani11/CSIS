

<?php $__env->startSection('title','Amount Of Paid Visit Report'); ?>

<?php $__env->startSection('card_title','Amount Of Paid Visit Report'); ?>

<?php $__env->startSection('isi'); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/tema', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\CSIS\resources\views/report/amount_of_paid_visit.blade.php ENDPATH**/ ?>