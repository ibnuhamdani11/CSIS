

<?php $__env->startSection('title','Equipment Used Report'); ?>

<?php $__env->startSection('card_title','Equipment Used Report'); ?>

<?php $__env->startSection('isi'); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/tema', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\CSIS\resources\views/report/equipment_used.blade.php ENDPATH**/ ?>