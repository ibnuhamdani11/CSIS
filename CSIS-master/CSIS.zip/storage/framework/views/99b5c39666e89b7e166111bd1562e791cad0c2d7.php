

<?php $__env->startSection('title','Detail Surat Perintah Kerja'); ?>

<?php $__env->startSection('card_title','Detail Surat Perintah Kerja'); ?>

<?php $__env->startSection('isi'); ?>
                            <div class="row">
						        <div class="col-md-12 ">
							        <div class="x_panel">
                                    <div class="table-responsive">
                  <table class="table table-bordered">
                      <thead style="background:#6495ED;">
                        <tr>
                        <th scope="col">No</th>
                          <th scope="col">SPK Number</th>
                          <th scope="col">SPK Date</th>
                          <th scope="col">Customer</th>
                          <th scope="col">Nomor Polisi</th>
                          <th scope="col">IMEI</th>
                          <th scope="col">GSM</th>
                          <th scope="col">Type</th>
                          <th scope="col">Remarks</th>
                        </tr>
                      </thead>
                      <tbody>
                      <?php
                          $no = 1;    
                      ?>
                      <?php $__currentLoopData = $spk_tabel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $spk_tabel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        <td><?php echo e($no++); ?></td>
                          <td><?php echo e($spk_tabel->spk->spk_number); ?></td>
                          <td><?php echo e($spk->spk_date); ?></td>
                          <td><?php echo e($spk->customer->name); ?></td>
                          <td><?php echo e($spk_tabel->nomor_polisi); ?></td>
                          <td><?php echo e($spk_tabel->imei); ?></td>
                          <td><?php echo e($spk_tabel->gsm_number); ?></td>
                          <td><?php echo e($spk->job_type); ?></td>
                          <td><?php echo e($spk->remarks); ?></td>

                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                    </table>

                   <a href="/maintenance" class="btn btn-secondary">Back</a>
											
                    </div>
                 </div>     
				</div>
			  </div>
		    </div>
           </div>
		

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts/tema', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\CSIS\resources\views/work order/detail_spk.blade.php ENDPATH**/ ?>