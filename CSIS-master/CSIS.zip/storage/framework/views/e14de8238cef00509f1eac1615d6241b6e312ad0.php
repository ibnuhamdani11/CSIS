

<?php $__env->startSection('title','Customer'); ?>

<?php $__env->startSection('card_title','Table Customer'); ?>

<?php $__env->startSection('isi'); ?>

<a href="/create_customer" class="btn btn-success">Add Customer</a>
                  <div class="table-responsive">
                  <table class="table table-striped">
                      <thead>
                        <tr>
                          <th scope="col">Action</th>
                          <th scope="col">Name</th>
                          <th scope="col">Short Name</th>
                          <th scope="col">Business Type</th>
                          <th scope="col">Business Conduct</th>
                          <th scope="col">NPWP</th>
                          <th scope="col">Remark</th>
                          <th scope="col">Active Ind</th>
                          <th scope="col">Control By</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <td>
                            
                          <a href="/edit/customer/<?php echo e($customer['id']); ?>"><img src="<?php echo e(asset('admin/assets/img/pencil (1).png')); ?>" width="20" height="20" ></a> 
                          <a href="/delete/customer/<?php echo e($customer['id']); ?>" ><img src="<?php echo e(asset('admin/assets/img/trash.png')); ?>" width="20" height="20" ></a>
                          </td>
                          <td><?php echo e($customer->name); ?></td>
                          <td><?php echo e($customer->short_name); ?></td>
                          <td><?php echo e($customer->business_type); ?></td>
                          <td><?php echo e($customer->business_conduct); ?></td>
                          <td><?php echo e($customer->npwp); ?></td>
                          <td><?php echo e($customer->remark); ?></td>
                          <td><?php echo e($customer->active_ind); ?></td>
                          <td><?php echo e($customer->control_by); ?></td>
                          
                          
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\CSIS\resources\views/customer.blade.php ENDPATH**/ ?>