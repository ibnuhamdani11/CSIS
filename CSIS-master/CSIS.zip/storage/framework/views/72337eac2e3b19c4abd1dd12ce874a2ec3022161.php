

<?php $__env->startSection('title','Request For Service'); ?>

<?php $__env->startSection('card_title','Request For Service'); ?>

<?php $__env->startSection('isi'); ?>

<a href="/create_rfs" class="btn btn-success">Add Request For Service</a>
                  <div class="table-responsive">
                  <table id="table_rfs" class="table table-striped">
                      <thead>
                        <tr>
                          <th scope="col">No</th>
                          <th scope="col">Request For Service Number</th>
                         
                          <th scope="col">Action</th>

                        </tr>
                      </thead>
                    </table>               
<?php $__env->stopSection(); ?>

<?php $__env->startSection("skrip"); ?>
<script type="text/javascript">
   //CSRF TOKEN PADA HEADER
  //Script ini wajib krn kita butuh csrf token setiap kali mengirim request post, patch, put dan delete ke server
$(document).ready(function () {
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });       
 //MULAI DATATABLE
 //script untuk memanggil data json dari server dan menampilkannya berupa datatable

table = $('#table_rfs').DataTable({
      processing: true,
      serverSide: true,
      ajax: '<?php echo e(url("/rfs/getdata")); ?>',
      columns: [
          {
              data: 'DT_RowIndex',
              name: 'DT_RowIndex'
          },
          {
              data: 'rfs_number',
              name: 'rfs_number'
          },
         
          {
              data: 'action',
              name: 'action'
          },
      ]
  });

  // =============== EDIT =========================
$('#formEdit').on("submit", function (e) {

e.preventDefault();

$('#editSubmit').html('Mengedit..');

var formData = new FormData(this);

$.ajax({

  data: formData,

  url: "<?php echo e(route('customer.update')); ?>",

  type: "POST",

  processData: false,

  contentType: false,

  success: function (data) {
    console.log(data);
    $('#formEdit').trigger("reset");
    $('#editSubmit').html('Edit');
    $('#editModal').modal('hide');
    $('.modal-backdrop').hide();
    table.draw();
  },

  error: function (data) {

    console.log('Error:', data);

    $('#editSubmit').html('Edit');

  }

});
});

$('body').on('click', '.editBtn', function () {

var id = $(this).data('id');

$.get("/edit/customer" +'/' + id , function (data) {

  $('#editModal').modal('show');
  // mengisi value berdasarkan id
  $('#name').val(data.name);
  // console.log(data.name);
  // otomatis select berdasarkan value
  $("#bt").val(data.bt_id);
  $("#bc").val(data.bc_id);
  $('#editId').val(data.id);

  // console.log(data.bc_id);
  $('#short_name').val(data.short_name);
  $('#id_business_type').val(data.id_business_type);
  $('#id_business_conduct').val(data.id_business_conduct);
  $('#npwp').val(data.npwp);
  $('#remarks').val(data.remarks);
  $('#active_ind').val(data.active_ind);

  

})
});


// ================== HAPUS ===================

$('body').on('click', '.hapusBtn', function () {

var id = $(this).data("id");    // Harus Data pakenya

confirm("Are You sure want to delete !");

$.ajax({

  type: "DELETE",

  url: '/delete/customer/'+id,

  success: function (data) {

    table.draw();

  },

  error: function (data) {

    console.log('Error:', data);

  }

});


});

});
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>;

<!-- Modal Edit -->
<div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="editHeader" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="editHeader">Edit Data Customer</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <form id="formEdit">
      <input type="hidden" id="editId" name="id"></input>
        <?php echo method_field('POST'); ?>
              <div class="form-group">
                  <label for="name">Name</label>
                  <input type="text" class="form-control" id="name"  name="name" value="">
                  <?php if($errors->has('name')): ?>
 
                    <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
 
                <?php endif; ?>
                </div>
                <div class="form-group">
                  <label for="sn">Short Name</label>
                  <input type="text" class="form-control" id="short_name" name="short_name" value="">
                </div>
                <div>
                  <label for="bt">Business Type</label>  
                  <!-- Button to Open the Modal -->
                  <a data-toggle="modal" data-target="#Modalbt"><img src="<?php echo e(asset('admin/assets/img/add.png')); ?>" width="10" height="10" ></i></a>
                 <select id='bt' name="bt" class="form-control">
                                            
                  </select>
                </div><br>
                
                <div>
                  <label for="bc">Business conduct</label>  
                  <!-- Button to Open the Modal -->
                  <a data-toggle="modal" data-target="#Modalbc"><img src="<?php echo e(asset('admin/assets/img/add.png')); ?>" width="10" height="10" ></i></a>
                 <select id='bc' name="bc" class="form-control">
                           
                              
                  </select>
                </div> <br>
                
                <div class="form-group">
                  <label for="npwp">Npwp</label>
                  <input type="text" class="form-control" id="npwp"  name="npwp" value="" >
                  <?php if($errors->has('npwp')): ?>
 
                    <span class="text-danger"><?php echo e($errors->first('npwp')); ?></span>
 
                <?php endif; ?>
                </div> <br>

                <div class="form-group">
                  <label for="remarks">Remarks</label>
                  <input type="text" class="form-control" id="remarks"  name="remarks" value="">
                </div> <br>

                <div class="form-group">
                    <label for="ai"  >Active Ind</label><br>
                    <input type="radio" name="ai" id="ai" value="Y"  > Yes<br>
                    <input type="radio"  name="ai" id="ai" value="N"  > No<br>
                </div>
               
                <div>
                  <label for="control_by">Business conduct</label>  
                  <!-- Button to Open the Modal -->
                  <a data-toggle="modal" data-target="#Modalcontrol_by"><img src="<?php echo e(asset('admin/assets/img/add.png')); ?>" width="10" height="10" ></i></a>
                 <select name="control_by" class="form-control">
                              <option value="IU" >Integrasia Utama</option>
                              <option value="SISI" >SISI</option>
                              <option value="AGIT" >AGIT</option>
                              
                  </select>
                </div>
                <button class="mt-2 btn btn-primary" id="editSubmit">Edit</button><br>
                </form>
    </div>
  </div>
</div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\CSIS\resources\views/rfs/rfs.blade.php ENDPATH**/ ?>