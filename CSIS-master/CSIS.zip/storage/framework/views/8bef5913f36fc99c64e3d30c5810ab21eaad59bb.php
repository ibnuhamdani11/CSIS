<!doctype html>
<html>
<head>
<title>Percabangan IF-ELSE</title>
</head>
<body>
<script language="JavaScript">
function tanyabilangan()
{
 var bil = parseFloat(document.fform.bilangan.value);
 var jenis = " ";
 if(isNaN(bil))
  {
   alert("Anda Belum memasukkan Bilangan");
  }
 else
 {  
   if (bil > 0)
    {
      jenis = " Adalah bilangan Positif";
    }
   else if (bil < 0)
    {
      jenis = " Adalah bilangan Negatif";
    }
   else
   {
      jenis = " Adalah Nol";
   }   
   alert (bil+" "+jenis);
 }  
}
</script>
<form name ="fform">
<H2><BR>Bilangan Negatif, Nol, Atau Positif ???</H2>
Masukkan Bilangan  :<input type="text" size="11" name="bilangan">
<P>
<input type="button" value="Tanya" onclick="tanyabilangan()">
<input type="reset" value="Ulang"> </p>
</form>   
</body>
</html><?php /**PATH C:\CSIS\resources\views/modal.blade.php ENDPATH**/ ?>