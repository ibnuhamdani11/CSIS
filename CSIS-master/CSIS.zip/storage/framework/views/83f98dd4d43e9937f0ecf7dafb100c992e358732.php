

<?php $__env->startSection('title','edit customer'); ?>

<?php $__env->startSection('card_title','Edit Customer'); ?>

<?php $__env->startSection('isi'); ?>


        <div class="card-body">
        <form method="post" action="/update_customer/<?php echo e($customer->id); ?>" autocomplete="off">
	          <?php echo csrf_field(); ?>
                <div class="form-group">
                  <label for="name">Name</label>
                  <input type="text" class="form-control" id="name"  name="name" value="<?php echo e($customer['name']); ?>">
                  <?php if($errors->has('name')): ?>
 
                    <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
 
                <?php endif; ?>
                </div>
                <div class="form-group">
                  <label for="sn">Short Name</label>
                  <input type="text" class="form-control" id="sn" name="sn" value="<?php echo e($customer['short_name']); ?>">
                </div>
                <div>
                  <label for="bt">Business Type</label>  
                  <!-- Button to Open the Modal -->
                  <a data-toggle="modal" data-target="#Modalbt"><img src="<?php echo e(asset('admin/assets/img/add.png')); ?>" width="10" height="10" ></i></a>
                 <select name="bt" class="form-control">
                              <option value="" >Choose business type</option>
                              <?php $__currentLoopData = $bt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($bt->id==$customer->id_business_type): ?>
                                <option value="<?php echo e($bt->id); ?>" selected='selected'><?php echo e($bt->business_type); ?></option>
                                <?php else: ?>
                                <option value="<?php echo e($bt->id); ?>"><?php echo e($bt->business_type); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div> <br>
                
                <div>
                  <label for="bc">Business conduct</label>  
                  <!-- Button to Open the Modal -->
                  <a data-toggle="modal" data-target="#Modalbc"><img src="<?php echo e(asset('admin/assets/img/add.png')); ?>" width="10" height="10" ></i></a>
                 <select name="bc" class="form-control">
                              <option value="" >Choose business conduct</option>
                              <?php $__currentLoopData = $bc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($bc->id==$customer->id_business_conduct): ?>
                                <option value="<?php echo e($bc->id); ?>" selected='selected'><?php echo e($bc->business_conduct); ?></option>
                                <?php else: ?>
                                <option value="<?php echo e($bc->id); ?>"><?php echo e($bc->business_conduct); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div> <br>
                
                <div class="form-group">
                  <label for="npwp">Npwp</label>
                  <input type="text" class="form-control" id="npwp"  name="npwp" value="<?php echo e($customer['npwp']); ?>" >
                  <?php if($errors->has('npwp')): ?>
 
                    <span class="text-danger"><?php echo e($errors->first('npwp')); ?></span>
 
                <?php endif; ?>
                </div> <br>

                <div class="form-group">
                  <label for="remarks">Remarks</label>
                  <input type="text" class="form-control" id="remarks"  name="remarks" value="<?php echo e($customer['remarks']); ?>">
                </div> <br>

                <div class="form-group">
                    <label for="ai">Active Ind</label><br>
                    <input type="radio" name="ai" value="Y"  <?php echo e($customer->active_ind == 'Y'? 'checked' : ''); ?>> Yes<br>
                    <input type="radio" name="ai" value="N"  <?php echo e($customer->active_ind == 'N'? 'checked' : ''); ?>> No<br>
                </div>
               
                <div>
                  <label for="control_by">Business conduct</label>  
                  <!-- Button to Open the Modal -->
                  <a data-toggle="modal" data-target="#Modalcontrol_by"><img src="<?php echo e(asset('admin/assets/img/add.png')); ?>" width="10" height="10" ></i></a>
                 <select name="control_by" class="form-control">
                              <option value="IU" >Integrasia Utama</option>
                              <option value="SISI" >SISI</option>
                              <option value="AGIT" >AGIT</option>
                              
                  </select>
                </div> <br>

                <!-- <div>
                  <label for="cb">Control By</label> 
                <a data-toggle="modal" data-target="#Modalcb"><img src="<?php echo e(asset('admin/assets/img/add.png')); ?>" width="10" height="10" ></i></a>

                    <select name="cb" class="form-control">
                          <option value="">Choose control by</option>
                              <option value="IU">IU</option>
                              <option value="SISI">SISI</option>
                              <option value="AGIT">AGIT</option>
                  </select>
                </div> <br> -->

                <button type="submit" class="btn btn-info btn-xs "> Save</button>
              </form>
                  </div>
                </div>
              </div>
            </div>
            </div>
          </div>
        </div>
      </div>
      
    
  </div>
 






 


 <!-- Modal -->
 <div class="modal fade" id="Modalbt" >
    <div class="modal-dialog" >
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" >Add Business Type</h5>
              <button type="button" class="close" data-dismiss="modal" >
                &times;
              </button>
              </div>
              <div class="modal-body">
              <form action="/store_bt" method="POST">
              <?php echo csrf_field(); ?>
                <div class="form-group">
                  <input name="bt" type="text" class="form-control" id="exampleInputEmail1">
                </div>
            </div>
            <div class="modal-footer">
              <button type="submit" class="btn btn-info">Save</button>
              </form>
          </div>
        </div>
      </div>
      </div>
      </div>


      <!-- Modal BRAND -->
 <div class="modal fade" id="Modalbc" >
    <div class="modal-dialog" >
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" >Add Business Conduct</h5>
              <button type="button" class="close" data-dismiss="modal" >&times;</button>
              </div>
              <div class="modal-body">
              <form action="/store_bc" method="POST">
              <?php echo csrf_field(); ?>
                <div class="form-group">
                  <input name="bc" type="text" class="form-control" id="exampleInputEmail1">
                </div>
            </div>
            <div class="modal-footer">
              <button type="submit" class="btn btn-info">Save</button>
              </form>
          </div>
        </div>
      </div>
      </div>
      </div>


        <!-- Modal SERIES -->
 <div class="modal fade" id="Modalseries" >
    <div class="modal-dialog" >
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" >Add Series</h5>
              <button type="button" class="close" data-dismiss="modal" >&times;</button>
              </div>
              <div class="modal-body">
              <form action="/store_series" method="POST">
              <?php echo csrf_field(); ?>
                <div class="form-group">
                  <input name="series" type="text" class="form-control" id="exampleInputEmail1">
                </div>
            </div>
            <div class="modal-footer">
              <button type="submit" class="btn btn-info">Save</button>
              </form>
          </div>
        </div>
      </div>
      </div>
      </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\CSIS\resources\views/customer/edit_customer.blade.php ENDPATH**/ ?>