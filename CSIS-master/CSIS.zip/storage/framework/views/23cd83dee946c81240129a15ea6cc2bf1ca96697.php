

<?php $__env->startSection('title','Terminate And Activation Of Gsm Report'); ?>

<?php $__env->startSection('card_title','Terminate And Activation Of Gsm Report'); ?>

<?php $__env->startSection('isi'); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/tema', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\CSIS\resources\views/report/terminate_activation_gsm.blade.php ENDPATH**/ ?>