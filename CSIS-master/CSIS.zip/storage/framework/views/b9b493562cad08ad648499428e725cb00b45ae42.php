

<?php $__env->startSection('title','Visitation Report'); ?>

<?php $__env->startSection('card_title','Visitation Report'); ?>

<?php $__env->startSection('isi'); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/tema', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\CSIS\resources\views/report/visitation_report.blade.php ENDPATH**/ ?>