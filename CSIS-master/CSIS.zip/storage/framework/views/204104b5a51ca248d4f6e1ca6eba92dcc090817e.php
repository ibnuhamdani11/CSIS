

<?php $__env->startSection('title','part'); ?>

<?php $__env->startSection('card_title','Add Part'); ?>

<?php $__env->startSection('isi'); ?>


<div class="col-md-10 "><div class="x_panel">
								<div class="x_title">

                <div class="clearfix"></div>
								</div>
								<div class="x_content">
									<br />
                 <form m method="POST" action="/update/part/<?php echo e($part->id); ?>" autocomplete="off" class="form-horizontal form-label-left">
                 <?php echo method_field('patch'); ?>
                 <?php echo csrf_field(); ?>

										<div class="form-group row ">
											<label class="control-label col-md-3 col-sm-3 label-align">Part</label>
											<div class="col-md-9 col-sm-9 ">
												<input type="text" class="form-control" placeholder=" Input Part"  value="<?php echo e($part['part']); ?>">
											</div>
										</div>
										
										<div class="form-group row">
											<label class="control-label col-md-3 col-sm-3 label-align">Series <a data-toggle="modal" data-target="#Modalseries" class="btn btn-warning btn-sm">+</a>
                     					    </label>
											<div class="col-md-9 col-sm-9 ">
												<select name="series" class="form-control">
												<?php if($part->series!==null): ?>
												<option selected='selected'><?php echo e($part->series); ?></option>
												<?php $__currentLoopData = $series; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $series): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option value="<?php echo e($series->series); ?>" ><?php echo e($series->series); ?></option>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												
												<?php else: ?>
												<option>Choose Brand</option>
												<?php $__currentLoopData = $series; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $series): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option value="<?php echo e($series->series); ?>" ><?php echo e($series->series); ?></option>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

												<?php endif; ?>
												</select>
											</div>
										</div>

                    <div class="form-group row">
											<label class="control-label col-md-3 col-sm-3 label-align">Type <a data-toggle="modal" data-target="#Modaltype" class="btn btn-warning btn-sm">+</a></label>
											<div class="col-md-9 col-sm-9 ">
												<select name="type" class="form-control">
												<?php if($part->type!==null): ?>
												<option selected='selected'><?php echo e($part->type); ?></option>
												<?php $__currentLoopData = $type1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option value="<?php echo e($type->type); ?>" ><?php echo e($type->type); ?></option>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												
												<?php else: ?>
												<option>Choose Type</option>
												<?php $__currentLoopData = $type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option value="<?php echo e($type->type); ?>" ><?php echo e($type->type); ?></option>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

												<?php endif; ?>
														
												</select>
											</div>
										</div>

                    <div class="form-group row">
											<label class="control-label col-md-3 col-sm-3 label-align">Brand <a data-toggle="modal" data-target="#Modalbrand" class="btn btn-warning btn-sm">+</a></label>
											<div class="col-md-9 col-sm-9 ">
												<select name="merk"  class="form-control">
												<?php if($part->merk!==null): ?>
												<option selected='selected'><?php echo e($part->merk); ?></option>
												<?php $__currentLoopData = $merk1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $merk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option value="<?php echo e($merk->merk); ?>" ><?php echo e($merk->merk); ?></option>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												
												<?php else: ?>
												<option>Choose Brand</option>
												<?php $__currentLoopData = $merk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $merk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option value="<?php echo e($merk->merk); ?>" ><?php echo e($merk->merk); ?></option>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

												<?php endif; ?>
												</select>
											</div>
										</div>

                    <div class="form-group row ">
											<label class="control-label col-md-3 col-sm-3 label-align">Uom</label>
											<div class="col-md-9 col-sm-9 ">
												<input type="text" name="uom"  class="form-control" placeholder="Input Uom"  value="<?php echo e($part['uom']); ?>">
											</div>
										</div>
									
                    <div class="form-group row">
                    <label class="control-label col-md-3 col-sm-3 label-align" for="sc">Serialized Code</label><br>
                    <div class="col-md-9 col-sm-9 ">
                    <input type="radio" name="sc" value="Y"  <?php echo e($part->serialized_code == 'Y'? 'checked' : ''); ?>> Yes<br>
                    <input type="radio" name="sc" value="N"  <?php echo e($part->serialized_code == 'N'? 'checked' : ''); ?>> No<br>
                    </div>
                </div>

										<div class="ln_solid"></div>
										<div class="form-group">
											<div class="col-md-9 col-sm-9  offset-md-3">
												<button type="submit" class="btn btn-success">Save</button>
											</div>
										</div>

									</form>
								</div>
							</div>
						</div>

   


			
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/tema', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\CSIS\resources\views/part/edit_part.blade.php ENDPATH**/ ?>