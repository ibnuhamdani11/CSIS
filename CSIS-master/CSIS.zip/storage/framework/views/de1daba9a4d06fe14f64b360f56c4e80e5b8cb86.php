

<?php $__env->startSection('title','part'); ?>

<?php $__env->startSection('card_title','Add Part'); ?>

<?php $__env->startSection('isi'); ?>


        <div class="card-body">
        <form method="post" action="/store_gps" autocomplete="off">
	          <?php echo csrf_field(); ?>
               
                <div>
                  <label for="part">Part</label>  
                 <select name="part" class="form-control">
                              <option value="" >Choose part</option>
                            <?php $__currentLoopData = $part; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $part): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($part->id); ?>"><?php echo e($part->part); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div> <br>

                <div class="form-group">
                  <label for="quantity">quantity</label>
                  <input type="text" class="form-control" id="quantity" placeholder="input quantity" name="quantity" required>
                </div><br>
                <div class="form-group">
                  <label for="uom">uom</label>
                  <input type="text" class="form-control" id="uom" placeholder="input uom" name="uom" required>
                </div>
                     
                <button type="submit" class="btn btn-info btn-xs "> Save</button>
              </form>
                  </div>
                </div>
              </div>
            </div>
            </div>
          </div>
        </div>
      </div>
      
    
  </div>
 






 


 <!-- Modal -->
 <div class="modal fade" id="Modaltype" >
    <div class="modal-dialog" >
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" >Add Type</h5>
              <button type="button" class="close" data-dismiss="modal" >
                &times;
              </button>
              </div>
              <div class="modal-body">
              <form action="/store_type" method="POST" autocomplete="off">
              <?php echo csrf_field(); ?>
                <div class="form-group">
                  <input name="type" type="text" class="form-control" id="exampleInputEmail1">
                </div>
            </div>
            <div class="modal-footer">
              <button type="submit" class="btn btn-info">Save</button>
              </form>
          </div>
        </div>
      </div>
      </div>
      </div>


      <!-- Modal BRAND -->
 <div class="modal fade" id="Modalbrand" >
    <div class="modal-dialog" >
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" >Add Brand</h5>
              <button type="button" class="close" data-dismiss="modal" >&times;</button>
              </div>
              <div class="modal-body">
              <form action="/store_brand" method="POST" autocomplete="off">
              <?php echo csrf_field(); ?>
                <div class="form-group">
                  <input name="merk" type="text" class="form-control" id="exampleInputEmail1">
                </div>
            </div>
            <div class="modal-footer">
              <button type="submit" class="btn btn-info">Save</button>
              </form>
          </div>
        </div>
      </div>
      </div>
      </div>


        <!-- Modal SERIES -->
 <div class="modal fade" id="Modalseries" >
    <div class="modal-dialog" >
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" >Add Series</h5>
              <button type="button" class="close" data-dismiss="modal" >&times;</button>
              </div>
              <div class="modal-body">
              <form action="/store_series" method="POST" autocomplete="off">
              <?php echo csrf_field(); ?>
                <div class="form-group">
                  <input name="series" type="text" class="form-control" id="exampleInputEmail1">
                </div>
            </div>
            <div class="modal-footer">
              <button type="submit" class="btn btn-info">Save</button>
              </form>
          </div>
        </div>
      </div>
      </div>
      </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\CSIS\resources\views/inventory/create_gps.blade.php ENDPATH**/ ?>