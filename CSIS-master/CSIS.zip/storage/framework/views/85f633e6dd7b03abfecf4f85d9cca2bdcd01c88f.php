

<?php $__env->startSection('title','part'); ?>

<?php $__env->startSection('card_title','Part'); ?>

<?php $__env->startSection('isi'); ?>

<a href="/create_mp" class="btn btn-success">Add Part</a>
                  <div class="table-responsive">
                  <table class="table table-striped">
                      <thead>
                        <tr>
                          <th scope="col">Action</th>
                          <th scope="col">Part</th>
                          <th scope="col">Series</th>
                          <th scope="col">Type</th>
                          <th scope="col">Brand</th>
                          <th scope="col">Serialized Code</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <?php $__currentLoopData = $part; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $part): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <td>
                            
                          <a href="/edit/part/<?php echo e($part['id']); ?>"><img src="<?php echo e(asset('admin/assets/img/pencil (1).png')); ?>" width="20" height="20" ></a> 
                          <a href="/delete/part/<?php echo e($part['id']); ?>"  onclick="return confirm ('Apa Anda yakin ingin menghapus ini')" ><img src="<?php echo e(asset('admin/assets/img/trash.png')); ?>" width="20" height="20" ></a>
                          </td>
                          <td><?php echo e($part->part); ?></td>
                          <?php if(empty($part->id_series)): ?>
                              <td><?php echo e($part->id_series); ?></td> 
                            <?php else: ?>
                              <td><?php echo e($part->series->series); ?></td>
                            <?php endif; ?>
                          
                            <?php if(empty($part->id_type)): ?>
                              <td><?php echo e($part->id_type); ?></td>         
                            <?php else: ?>
                              <td><?php echo e($part->type->type); ?></td>
                            
                            <?php endif; ?>  
                          

                          <?php if(empty($part->id_merk)): ?>
                            
                              <td><?php echo e($part->id_merk); ?></td>         
                            <?php else: ?>
                              <td><?php echo e($part->merk->merk); ?></td>
                            
                            <?php endif; ?>
                          
                          <td><?php echo e($part->serialized_code); ?></td>
                          
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\CSIS\resources\views/home.blade.php ENDPATH**/ ?>