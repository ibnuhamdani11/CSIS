

<?php $__env->startSection('title','Terminate Of GSM Error Report'); ?>

<?php $__env->startSection('card_title','Terminate Of GSM Error Report'); ?>

<?php $__env->startSection('isi'); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/tema', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\CSIS\resources\views/report/terminate_of_gsm_erorr.blade.php ENDPATH**/ ?>