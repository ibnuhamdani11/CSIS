<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Material_receipt_header extends Model
{
    protected $table = 'material_receipt_header';

}
