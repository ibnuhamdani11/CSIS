<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Issue_to extends Model
{
    protected $table = 'issue_to';
}
